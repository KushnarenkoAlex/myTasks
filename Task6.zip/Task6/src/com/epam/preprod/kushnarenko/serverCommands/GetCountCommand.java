package com.epam.preprod.kushnarenko.serverCommands;

import com.epam.preprod.kushnarenko.logic.Shop;

public class GetCountCommand implements ServerCommand {

	@Override
	public String execute(String s) {
		Shop shop = Shop.getInstance();
		return "Count = " + shop.getCount();
	}

}
