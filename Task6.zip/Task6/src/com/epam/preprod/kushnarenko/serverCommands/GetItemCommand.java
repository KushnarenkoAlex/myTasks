package com.epam.preprod.kushnarenko.serverCommands;

import com.epam.preprod.kushnarenko.entity.Product;
import com.epam.preprod.kushnarenko.logic.Shop;

public class GetItemCommand implements ServerCommand {

	@Override
	public String execute(String s) {
		Shop shop = Shop.getInstance();
		Product p = shop.getItem(Integer.parseInt(s));
		return "Product = " + p.getId() + " | " + p.getPrice();
	}

}
