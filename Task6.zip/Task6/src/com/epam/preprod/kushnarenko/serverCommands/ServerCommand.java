package com.epam.preprod.kushnarenko.serverCommands;

public interface ServerCommand {
	
	public String execute(String s);

}
