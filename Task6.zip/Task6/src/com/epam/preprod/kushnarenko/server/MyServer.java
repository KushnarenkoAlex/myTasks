package com.epam.preprod.kushnarenko.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import com.epam.preprod.kushnarenko.processor.MyServerHttpProcessor;

public class MyServer extends Thread {

	ServerSocket sock;
	int port;

	public MyServer(int port, String string) {
		setDaemon(true);
		this.start();
		this.port = port;
	}

	@Override
	public void run() {
		try {
			sock = new ServerSocket(port);
			while (true) {
				Socket s = sock.accept();
				MyServerHttpProcessor server = new MyServerHttpProcessor(s);
				// MyServerTCPProcessor server = new MyServerTCPProcessor(s);
				server.start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
