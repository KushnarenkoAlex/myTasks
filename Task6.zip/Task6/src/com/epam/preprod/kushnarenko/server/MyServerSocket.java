package com.epam.preprod.kushnarenko.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;

import com.epam.preprod.kushnarenko.util.Const;

public class MyServerSocket {

	public void start(int port) {

	}

	public static void main(String[] args) {

		Socket s = null;

		try {
			ServerSocket ss = new ServerSocket(Const.PORT);
			s = ss.accept();
			PrintStream ps = new PrintStream(s.getOutputStream());
			ps.println("������!");
			BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			String str = br.readLine();
			ps.println(str + " server");
			// System.out.println(str);
			ps.flush();
			ps.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (s != null)
				try {
					s.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

		}

	}
}
