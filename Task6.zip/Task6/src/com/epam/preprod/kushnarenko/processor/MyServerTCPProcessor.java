package com.epam.preprod.kushnarenko.processor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.Socket;

import com.epam.preprod.kushnarenko.serverCommands.Commands;
import com.epam.preprod.kushnarenko.serverCommands.ServerCommand;

public class MyServerTCPProcessor extends Thread {

	private PrintStream os;
	BufferedReader is;
	InetAddress addr;

	public MyServerTCPProcessor(Socket s) throws IOException {
		os = new PrintStream(s.getOutputStream());
		is = new BufferedReader(new InputStreamReader(s.getInputStream()));
		addr = s.getInetAddress();
	}

	public void run() {
		String str;
		try {
			while ((str = is.readLine()) != null) {
				String[] ss = str.split("=");
				ServerCommand c = Commands.get(ss[0]);
				if (ss.length == 1) {
					os.println(c.execute(null));
				} else {
					os.println(c.execute(ss[1]));
				}
			}
		} catch (Exception e) {
			System.out.println("Disconnect");
		} finally {
			disconnect();
		}
	}

	private void disconnect() {
		try {
			os.close();
			is.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			// this.interrupt();
		}
	}
}
