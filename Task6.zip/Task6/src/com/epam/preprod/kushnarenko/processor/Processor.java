package com.epam.preprod.kushnarenko.processor;

public interface Processor {

}
