package com.epam.preprod.kushnarenko.processor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.sound.midi.spi.MidiFileWriter;

import com.epam.preprod.kushnarenko.serverCommands.Commands;
import com.epam.preprod.kushnarenko.serverCommands.ServerCommand;

public class MyServerHttpProcessor extends Thread {

	private PrintStream os;
	BufferedReader is;
	InetAddress addr;

	public MyServerHttpProcessor(Socket s) throws IOException {
		os = new PrintStream(s.getOutputStream());
		is = new BufferedReader(new InputStreamReader(s.getInputStream()));
		addr = s.getInetAddress();
	}

	@Override
	public void run() {
		String str;
		try {
			str = is.readLine();
			Pattern urlPat = Pattern.compile("GET /shop/(.*) HTTP/(.*)");
			Matcher m = urlPat.matcher(str);
			if (m.matches()) {
				str = m.group(1);
			}
			Pattern commandPat = Pattern.compile("(.*)\\?(.*)");
			Matcher m2 = commandPat.matcher(str);
			ServerCommand sc;
			if (m2.matches()) {
				sc = Commands.get(m2.group(1));
				str = m2.group(2);
			} else {
				sc = Commands.get(str);
			}
			if (sc.equals(null)) {
				throw new UnsupportedOperationException();
			}
			String res = sc.execute(str);
			writeResponse("<html><body><h1>" + res + "</h1></body></html>");
		} catch (Exception e) {
			System.out.println("Disconnect");
		} finally {
			disconnect();
		}
	}

	private void disconnect() {
		try {
			os.close();
			is.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			// this.interrupt();
		}
	}

	private void writeResponse(String s) throws IOException {
		String response = "HTTP/1.1 200 OK\r\n" + "Server: YarServer/2009-09-09\r\n" + "Content-Type: text/html\r\n"
				+ "Content-Length: " + s.length() + "\r\n" + "Connection: close\r\n\r\n";
		String result = response + s;
		os.write(result.getBytes());
		os.flush();
	}

}
