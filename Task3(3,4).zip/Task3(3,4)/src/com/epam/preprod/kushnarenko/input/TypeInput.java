package com.epam.preprod.kushnarenko.input;

import java.util.Scanner;

import com.epam.preprod.kushnarenko.entity.Product;

public interface TypeInput {
	public void execute(Product p,Scanner s);
}
