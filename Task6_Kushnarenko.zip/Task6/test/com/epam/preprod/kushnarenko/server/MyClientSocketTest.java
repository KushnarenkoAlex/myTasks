package com.epam.preprod.kushnarenko.server;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;

import org.junit.Test;

import com.epam.preprod.kushnarenko.logic.Shop;

public class MyClientSocketTest {
	@Test
	public void testMain() {
		ByteArrayInputStream bais = new ByteArrayInputStream("get count".getBytes());
		InputStream is = System.in;
		System.setIn(bais);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		System.setOut(new PrintStream(baos));
		Shop shop = mock(Shop.class);
		when(shop.getCount()).thenReturn("10");
		MyClientSocket.main(null);
		assertEquals("Count: 12", baos.toString().trim());
		System.setIn(is);
	}

}
