package com.epam.preprod.kushnarenko.processor;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;

import org.junit.Test;

import com.epam.preprod.kushnarenko.logic.Shop;
import com.epam.preprod.kushnarenko.util.Const;

public class MyTCPProcessorTest {

	ByteArrayInputStream bais;
	InputStream is = System.in;

	@Test
	public void testRun() {
		bais = new ByteArrayInputStream("get count".getBytes());
		System.setIn(bais);
		MyTCPProcessor mtp=null;
		try {
			mtp = new MyTCPProcessor(new Socket(Const.HOST, Const.PORT3000));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Shop shop = mock(Shop.class);
		when(shop.getCount()).thenReturn("10");

	}

	@Test
	public void testMyTCPProcessor() {
		try {
			MyTCPProcessor mtp = new MyTCPProcessor(new Socket(Const.HOST, Const.PORT3000));
		} catch (IOException e) {
		}
	}

}
