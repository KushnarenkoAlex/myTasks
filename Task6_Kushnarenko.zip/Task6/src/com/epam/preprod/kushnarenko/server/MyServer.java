package com.epam.preprod.kushnarenko.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import com.epam.preprod.kushnarenko.processor.IProcessor;

public class MyServer extends Thread {

	ServerSocket sock;
	int port;
	String type;

	public MyServer(int port, String type) {
		setDaemon(true);
		this.start();
		this.port = port;
		this.type = type;
	}

	@Override
	public void run() {
		try {
			sock = new ServerSocket(port);
			while (true) {
				Socket s = sock.accept();
				IProcessor ip = AbstractServerFactory.getProcess(s, type);
				ip.start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
