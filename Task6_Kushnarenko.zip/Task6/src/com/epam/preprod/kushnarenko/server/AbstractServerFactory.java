package com.epam.preprod.kushnarenko.server;

import java.io.IOException;
import java.net.Socket;

import com.epam.preprod.kushnarenko.processor.IProcessor;
import com.epam.preprod.kushnarenko.util.Const;

abstract class AbstractServerFactory {

	abstract public IProcessor createServer(Socket s) throws IOException;

	public static IProcessor getProcess(Socket sock, String server) throws IOException {
		AbstractServerFactory asf;
		if (server.equals(Const.TCP)) {
			asf = new TCPServerFactory();
		} else {
			asf = new HTTPServerFactory();
		}
		return asf.createServer(sock);
	}

}
