package com.epam.preprod.kushnarenko.processor;

public interface IProcessor {
	public void start();
}
