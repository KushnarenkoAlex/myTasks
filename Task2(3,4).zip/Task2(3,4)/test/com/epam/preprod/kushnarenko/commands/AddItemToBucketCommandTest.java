package com.epam.preprod.kushnarenko.commands;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;

import org.junit.Before;
import org.junit.Test;

import com.epam.preprod.kushnarenko.logic.ConsoleWorker;
import com.epam.preprod.kushnarenko.logic.Shop;

public class AddItemToBucketCommandTest {

	Command c;

	@Before
	public void initialize() {
		c = new AddItemToBucketCommand();
	}

	@Test
	public void executeTest() {
		Shop shop = new Shop();
		ConsoleWorker cw = new ConsoleWorker();
		PrintStream originalOut = System.out;
		OutputStream os = new ByteArrayOutputStream();
		PrintStream ps = new PrintStream(os);
		c.execute(shop, cw);
		System.setOut(ps);
		System.setOut(originalOut);
		System.out.println(os);
		assertEquals(4, os.toString().split("\n").length);
	}

}
