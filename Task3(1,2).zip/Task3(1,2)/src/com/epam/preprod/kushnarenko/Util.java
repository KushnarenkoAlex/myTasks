package com.epam.preprod.kushnarenko;

import java.io.File;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

public class Util {

	public static Collection<File> findFiles(File directory) {
		List<File> list = new LinkedList<File>();
		for (File file : directory.listFiles()) {
			if (!file.isFile()) {
				list.addAll(findFiles(file));
			} else {
				list.add(file);
			}
		}
		return list;
	}

}
