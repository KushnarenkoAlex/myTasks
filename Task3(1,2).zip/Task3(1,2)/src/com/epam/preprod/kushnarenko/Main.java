package com.epam.preprod.kushnarenko;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Scanner;

import com.epam.preprod.kushnarenko.chain.DateFilter;
import com.epam.preprod.kushnarenko.chain.Filter;
import com.epam.preprod.kushnarenko.chain.FormatFilter;
import com.epam.preprod.kushnarenko.chain.NameFilter;
import com.epam.preprod.kushnarenko.chain.SizeFilter;

public class Main {

	private static boolean input(String question, Scanner sc) {
		while (true) {
			System.out.print(question);
			String answer = sc.nextLine();
			if (answer.equals("1")) {
				return true;
			}
			if (answer.equals("0")) {
				return false;
			}
			System.err.println(Const.TYPE_ONE_OR_ZERO);
		}
	}

	private static String getString(String message, Scanner sc) {
		System.out.print(message);
		String answer = sc.nextLine();
		return answer;
	}

	public static void main(String[] args) {

		System.out.print(Const.INPUT_DIR);

		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		Collection<File> al = Util.findFiles(new File(s));
		Filter ff = null;
		System.err.println("YO");
		if (input(Const.FIND_BY_NAME, sc)) {
			s = getString(Const.INPUT_WORD, sc);
			ff = new NameFilter(ff, s);
		}
		if (input(Const.FIND_BY_FORMAT, sc)) {
			s = getString(Const.INPUT_FORMAT, sc);
			ff = new FormatFilter(ff, s);
		}
		
		if (input(Const.FIND_BY_SIZE, sc)) {
			s = getString(Const.INPUT_SIZE, sc);
			String[] ss = s.split(" ");
			try {
				Long from = Long.parseLong(ss[0]);
				Long to = Long.parseLong(ss[1]);
				ff = new SizeFilter(ff, from, to);
			} catch (Exception e) {
				System.err.println(Const.WRONG_SIZE);
			}
		}

		if (input(Const.FIND_BY_DATE, sc)) {
			String dateFrom = getString(Const.INPUT_DATE_FROM, sc);
			String dateTo = getString(Const.INPUT_DATE_TO, sc);
			SimpleDateFormat sdf = new SimpleDateFormat("dd MM yyyy HH mm");
			Date from = new Date();
			Date to = new Date();
			try {
				from = sdf.parse(dateFrom);
				to = sdf.parse(dateTo);
				ff = new DateFilter(ff, from, to);
			} catch (Exception e) {
				System.err.println(Const.WRONG_DATE);
			}
		}
		
		for (File f : al) {
			if (ff != null) {
				if (ff.filterData(f)) {
					System.out.println(f);
				}
			} else {
				System.out.println(f);
			}
		}
	}
}
