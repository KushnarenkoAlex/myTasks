package com.epam.preprod.kushnarenko.Sequence;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.epam.preprod.kushnarenko.SimpleNumbers.Const;

public class Demo {

	public static ArrayList<Character> al;

	// public static final Object monitor = new Object();

	public static boolean done;

	public static void findSequence(ArrayList<Character> al) {
		int len = 2;
		while (len < al.size()) {
			for (int pos = 0; pos <= al.size() - len; pos++) {
				{
					List<Character> temp = al.subList(pos, pos + len);
					for (int i = pos + 1; i <= al.size() - len; i++) {
						List<Character> temp2 = al.subList(i, i + len);
						if (temp2.equals(temp)) {
							len++;
							System.out.println(temp2);
							break;
						}
					}
					break;
				}
			}
		}
	}

	public static void main(String[] args) throws IOException, InterruptedException {
		Object monitor = new Object();
		SequenceThread st = new SequenceThread(monitor);
		st.start();
		done = false;
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		synchronized (monitor) {
			while (true) {
				System.out.println("Type file name or exit");
				String s = sc.nextLine();
				if (s.equals(Const.EXIT)) {
					break;
				}
				done = false;
				InputStream is = new FileInputStream(s);
				al = new ArrayList<>();
				for (int b = is.read(); b >= 0; b = is.read()) {
					al.add(new Character((char) b));
				}
				while (!done) {
					monitor.notifyAll();
					monitor.wait();
					System.out.println(st.getS());
				}
				is.close();
			}
		}
		System.out.println("DONEAPP");
	}
}
