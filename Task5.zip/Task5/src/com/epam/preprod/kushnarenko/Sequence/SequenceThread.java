package com.epam.preprod.kushnarenko.Sequence;

import java.util.ArrayList;
import java.util.List;

public class SequenceThread extends Thread {

	private Object monitor;

	private String s;

	public SequenceThread(Object o) {
		setDaemon(true);
		monitor = o;
	}

	public String getS() {
		return s;
	}

	@Override
	public void run() {
		s=null;
		synchronized (monitor) {
			try {
				System.out.println("BEGAN THREAD");
				monitor.wait();
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			ArrayList<Character> al = Demo.al;
			int len = 2;
			while (len < al.size()) {
				boolean flag = false;
				for (int pos = 0; pos <= al.size() - len; pos++) {
					List<Character> temp = al.subList(pos, pos + len);
					for (int i = pos + 1; i <= al.size() - len; i++) {
						List<Character> temp2 = al.subList(i, i + len);
						if (temp2.equals(temp)) {
							flag = true;
							len++;
							s = temp2.toString();
							monitor.notifyAll();
							try {
								monitor.wait();
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
							break;
						}
					}
					break;
				}
				if (!flag) {
					break;
				}
			}
			Demo.done = true;
			monitor.notifyAll();
		}
	}
}
