package com.epam.preprod.kushnarenko.SimpleNumbers;

public class Const {
	public static final String INPUT = "Input value(n m)";
	public static final String WRONG = "Wrong";
	public static final String EXIT = "exit";
	
}
