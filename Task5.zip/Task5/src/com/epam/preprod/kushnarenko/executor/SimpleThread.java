package com.epam.preprod.kushnarenko.executor;

import java.util.ArrayList;

public class SimpleThread implements Runnable {

	private int i, k;
	private ArrayList<Integer> al;

	public SimpleThread(int i, int k, ArrayList<Integer> al) {
		System.out.println("FROM " + i + " TO " + (i + k));
		this.i = i;
		this.k = k;
		this.al = al;
	}

	@Override
	public void run() {
		for (int z = i; z < i + k; z++) {
			boolean flag = true;
			if (flag) {
				for (int j = 2; j <= z / 2; j++) {
					if (z % j == 0) {
						flag = false;
						break;
					}
				}
			}
			if (flag) {
				synchronized (al) {
					//System.out.println(z);// + " " + this.toString());
					al.add(z);
				}
			}
		}
	}

	// @Override
	// public void run() {
	// for (int z = i; z < i + k; z++) {
	// boolean flag = true;
	// if (flag) {
	// for (int j = 2; j <= z / 2; j++) {
	// if (z % j == 0) {
	// flag = false;
	// break;
	// }
	// }
	// }
	// if (flag) {
	// synchronized (al) {
	// System.out.println(z + " " + this.getName());
	// al.add(z);
	// }
	// }
	// }
	// }
}
