package com.epam.preprod.kushnarenko;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Scanner;

import com.epam.preprod.kushnarenko.annotation.MyAnno;
import com.epam.preprod.kushnarenko.entity.MountainBike;

public class InputWorker {

	Scanner sc;
	ResourceBundle rb;

	public InputWorker() {
		sc = new Scanner(System.in);
		System.out.println("ru/en");
		String locale = sc.nextLine();
		rb = ResourceBundle.getBundle("locale", new Locale(locale));
	}

	void printAnnotatedFields(Object o)
			throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException,
			InstantiationException, ClassNotFoundException, NoSuchMethodException, InvocationTargetException {
		ArrayList<Method> ff = new ArrayList<Method>();
		Class<?> b = o.getClass();
		while (b.getSuperclass() != null) {
			ff.addAll(Arrays.asList(b.getDeclaredMethods()));
			b = b.getSuperclass();
		}
		for (Method f : ff) {
			if (f.getAnnotation(MyAnno.class) != null) {
				if (f.getName().startsWith("set")) {
					System.out.println(rb.getString(f.getAnnotation(MyAnno.class).key()) + "("
							+ Arrays.asList(f.getParameters()).get(0).getType().getSimpleName() + ")");
					String s = sc.nextLine();
					Class<?> clazz = Arrays.asList(f.getParameters()).get(0).getType();
					Constructor<?> cons = clazz.getConstructor(String.class);
					Object obj = cons.newInstance(s);
					f.invoke(o, obj);
				}
			}
		}
	}

	public static void main(String[] args) {
		InputWorker iw = new InputWorker();
		MountainBike m = new MountainBike();
		try {
			iw.printAnnotatedFields(m);
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		}
		System.out.println(m);
	}
}
